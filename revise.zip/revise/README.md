# Neural Collapse Dynamics: What Sets the Feature Norm of the Collapsed State

Code, per-run logs, and the analysis notebook for this paper, submitted to
Neurocomputing as manuscript NEUCOM-D-26-15075.

Anamika Paul Rupa, Department of Information Science and Systems, Morgan State
University, Baltimore, MD 21251, USA. anamika.rupa@morgan.edu

One notebook recomputes every number in the paper and regenerates every figure from the
per-run logs in this repository. It needs no GPU and runs in well under a minute.

## Quick start

```
pip install -r requirements.txt
jupyter notebook NC_analysis.ipynb     # Run All
```

`NC_analysis.ipynb` reads `NC_experiments/runs/` and `supplementary_results/` from the
repository root and writes `NC_experiments/tables/` and `NC_experiments/figures/`. A copy
of those tables, and the figures as they appear in the paper, are already in `tables/` and
`figures/` so the numbers can be read without running anything.

On Google Colab the first cell mounts Drive and looks for the same two directories there.

## What is here

| Path | Contents |
|---|---|
| `NC_analysis.ipynb` | The analysis. Reads the logs, writes every table and figure. |
| `NC_experiments/runs/` | 431 log files from 143 training runs. |
| `NC_experiments/selections/` | The learning-rate screen's record: candidates, the rule, and the rate it chose. |
| `supplementary_results/` | 111 log files from the runs released with the original submission, which the notebook also reads. |
| `notebooks/` | The four GPU notebooks that produced the runs. |
| `tables/` | The tables the notebook writes, as CSV and one JSON. |
| `figures/` | The figures, at 600 dpi, as PDF and PNG. |
| `paper/` | LaTeX source, bibliography, and the norm-split table as CSV. |

### The training notebooks

| Notebook | Runs it produces |
|---|---|
| `notebooks/NC_grid_runs.ipynb` | `grid_*` — the main architecture by dataset grid. |
| `notebooks/NC_protocol_controls.ipynb` | `protocol_*` (loss schedule and target scale), `addon_wd*` (weight decay), `addon_*_adamw_*`, `addon_resnet_nobn_*`, and the unclipped SGD screen. |
| `notebooks/NC_protocol_controls_clipped_sgd.ipynb` | `addon_mlp_mnist_sgd_clip1_*` — the SGD arm with the gradient norm clipped at 1.0, and the `screen_*_clip1_*` learning-rate screen. |
| `notebooks/NC_feature_rescaling.ipynb` | `rescale_*` — the intervention arms and their controls. |

The four notebooks write into one flat run directory, which is why the runs here are a
single folder rather than one folder per notebook. Each `RUN_PARTS` flag at the top of the
protocol-controls notebook switches a group of runs on or off.

## Log format

Each run writes three files, named after the run.

`<run>.csv` — one row per evaluation. `epoch` counts from the start of training, so the
MSE phase is epochs 201 to 800 under the standard protocol. `phase` is 1 for cross-entropy
and 2 for mean squared error. Columns: `train` and `test` accuracy, `nc1`, `nc2`, `nc3`,
`feat_norm` (the mean penultimate feature norm), `feat_norm_centered`, `class_mean_norm`,
`logit_norm`, `clf_weight_norm`, `clf_bias_norm`, `param_norm`, `hidden_weight_norm`,
`sb_trace`, `degenerate`, `train_loss_eval`, `feat_dim`, the per-evaluation timings
`sec_forward`, `sec_fn_only` and `sec_nc_full`, and the training-epoch columns below. Rows
with a non-empty `event` mark an intervention and are not evaluations.

`<run>_epochs.csv` — one row per training epoch: `epoch`, `phase`, `phase_epoch`, `lr`,
`train_loss_epoch`, `grad_norm_epoch_mean`, `sec_train_epoch`. The compute table is built
from these.

`<run>_summary.json` — the configuration (`cfg`), a fingerprint of it, the GPU, the PyTorch
version, wall-clock seconds, and a `collapse` block holding the first, sustained and
terminal readings at NC1 < 0.05, 0.02 and 0.01 in each phase.

The older logs in `supplementary_results/` carry a smaller set of columns: `epoch`,
`phase`, `train`, `test`, `nc1`, `nc2`, `nc3`, `feat_norm`, with extra columns in the
`early_warning/` and `vit_crossarch/` subdirectories. The notebook infers the phase from
the epoch where a log has no `phase` column and flags that it did so.

## Conventions

Sample standard deviation with one degree of freedom. Student-t confidence intervals.
Ratios between conditions as Welch intervals on the log scale, with Hedges' g. The
architecture by dataset interaction is tested by a Freedman-Lane permutation test with
9999 permutations. fn* is always read at a stated NC1 criterion and values read at
different criteria are not comparable.

An evaluation counts as degenerate, and never as collapse, when the feature norm falls
below 1e-3 or NC1 below 1e-6.

## Runs

143 completed runs, all under PyTorch 2.11.0+cu128, 81 on a single NVIDIA A100-SXM4-80GB
and 62 on a single Tesla T4.

| Group | Runs | GPU hours |
|---|---|---|
| Grid, ResNet-20 on MNIST | 10 | 11.64 |
| Grid, MLP-5 on three datasets | 15 | 1.28 |
| Protocol controls | 25 | 2.14 |
| Weight decay | 15 | 1.31 |
| Optimiser controls | 20 | 4.48 |
| ResNet-20 without BatchNorm | 3 | 2.96 |
| Feature rescaling | 55 | 1.74 |

One run, `grid_resnet_fmnist_sgd_s0`, did not finish and has no summary file. The notebook
skips it.

## Figures

Eight of the figures in `figures/` appear in the paper: the graphical abstract, the two
grid panels, the norm split, the protocol controls, the feature rescaling, the weight
decay, and the width sweep. The other three, early warning, optimiser controls and
rescaling norms, are produced by the notebook but are not used in the paper. All are written at 600 dpi,
with TrueType fonts embedded and no Type 3 fonts.

## Citation

Please cite the paper. The `paper/` directory holds the LaTeX source and the bibliography.
